﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GraphDemo.Chart.ViewModels
{
    public class TooltipSeries
    {
        public List<List<int>> DataList { get; set; }
    }
}
